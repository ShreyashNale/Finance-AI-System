# ===============================================================
#                    INVESTMENT PREDICTION MODULE
# ===============================================================

import joblib
import numpy as np
import pandas as pd
import os

# ------------------------------
# LOAD MODELS & ENCODERS
# ------------------------------

def load_models():
    """Load all investment models and encoders"""
    try:
        model_rec1 = joblib.load("investment_recom/model_rec1.pkl")
        model_rec2 = joblib.load("investment_recom/model_rec2.pkl")
        model_rec3 = joblib.load("investment_recom/model_rec3.pkl")
        model_alloc = joblib.load("investment_recom/model_alloc.pkl")
        
        le_rec = joblib.load("investment_recom/label_encoder_recommendations.pkl")
        le_risk = joblib.load("investment_recom/label_encoder_risk.pkl")
        
        print("Investment models loaded successfully!")
        return {
            'model_rec1': model_rec1,
            'model_rec2': model_rec2,
            'model_rec3': model_rec3,
            'model_alloc': model_alloc,
            'le_rec': le_rec,
            'le_risk': le_risk
        }
    except Exception as e:
        print(f"Error loading investment models: {e}")
        return None

# Load models once
investment_models = load_models()

# ------------------------------
# RISK LEVEL BASED ON AGE
# ------------------------------

def get_risk_level(age):
    if age < 30:
        return "high"
    elif age < 45:
        return "medium"
    elif age < 60:
        return "low"
    else:
        return "very_low"

# ------------------------------
# STATIC REASONS FOR OUTPUT
# ------------------------------

reasons_map = {
    "Stocks": "Young investors can take higher risks for high long-term growth.",
    "SIP": "SIPs reduce market volatility impact and build long-term wealth.",
    "Gold": "Gold provides stability and hedges inflation.",
    "FD": "FD ensures capital protection with guaranteed returns.",
    "RD": "RD provides disciplined low-risk accumulation."
}

# ------------------------------
# PREDICTION FUNCTION
# ------------------------------

def predict_investment(age, income, savings, dependents, monthly_invest_amount):
    """Predict investment recommendations and allocations"""
    
    if investment_models is None:
        return {"error": "Investment models not loaded properly"}
    
    try:
        risk = get_risk_level(age)
        risk_encoded = investment_models['le_risk'].transform([risk])[0]

        # Final input row
        X_new = pd.DataFrame([[
            age,
            income,
            savings,
            dependents,
            monthly_invest_amount,
            risk_encoded
        ]], columns=[
            "age", "income", "savings", "dependents",
            "monthly_invest_amount", "risk_level"
        ])

        # -------------------------
        # Recommendation Predictions
        # -------------------------

        pred1_idx = investment_models['model_rec1'].predict(X_new)[0]
        pred2_idx = investment_models['model_rec2'].predict(X_new)[0]
        pred3_idx = investment_models['model_rec3'].predict(X_new)[0]

        rec1 = investment_models['le_rec'].inverse_transform([pred1_idx])[0]
        rec2 = investment_models['le_rec'].inverse_transform([pred2_idx])[0]
        rec3 = investment_models['le_rec'].inverse_transform([pred3_idx])[0]

        # -------------------------
        # Allocation Predictions
        # -------------------------

        alloc = investment_models['model_alloc'].predict(X_new)[0]
        alloc = alloc.round(2)

        amount1 = round(monthly_invest_amount * alloc[0] / 100, 2)
        amount2 = round(monthly_invest_amount * alloc[1] / 100, 2)
        amount3 = round(monthly_invest_amount * alloc[2] / 100, 2)
        
        # Convert numpy types to Python native types for JSON serialization
        amount1 = float(amount1)
        amount2 = float(amount2)
        amount3 = float(amount3)

        # -------------------------
        # Final Output
        # -------------------------

        return {
            "success": True,
            "risk_level": risk,
            "recommendations": [rec1, rec2, rec3],
            "allocation_percentage": alloc.tolist(),
            "allocation_amount": [amount1, amount2, amount3],
            "reasons": [
                reasons_map.get(rec1, "Recommended for your financial profile"),
                reasons_map.get(rec2, "Recommended for your financial profile"),
                reasons_map.get(rec3, "Recommended for your financial profile")
            ]
        }
        
    except Exception as e:
        return {"error": f"Prediction failed: {str(e)}"}

# ------------------------------
# TEST THE MODEL
# ------------------------------

if __name__ == "__main__":
    user_input = {
        "age": 22,
        "income": 70000,
        "savings": 500000,
        "dependents": 2,
        "monthly_invest_amount": 10000
    }

    result = predict_investment(**user_input)
    
    print("\n========= MODEL OUTPUT =========\n")
    print("User Input:", user_input)
    print("\nRisk Level:", result.get("risk_level", "N/A"))
    print("Recommendations:", result.get("recommendations", []))
    print("Allocation %:", result.get("allocation_percentage", []))
    print("Allocation Amount:", result.get("allocation_amount", []))
    print("\nReasons:")
    for r in result.get("reasons", []):
        print("-", r)