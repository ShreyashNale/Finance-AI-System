from flask import Flask, render_template, request, jsonify, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from flask_bcrypt import Bcrypt
import pandas as pd
import numpy as np
import joblib
import os
from datetime import datetime
from Investment_recom.predict_investment import predict_investment, investment_models

try:
    from google import genai
except ImportError:
    genai = None

GEMINI_API_KEY = "AIzaSyAIHNT9Vybjv5vycics60hovlfrEIbLaSw"
GEMINI_MODEL = "gemini-3-flash-preview"
gemini_client = None

if genai is not None and GEMINI_API_KEY and GEMINI_API_KEY != "PASTE_YOUR_GEMINI_API_KEY_HERE":
    gemini_client = genai.Client(api_key=GEMINI_API_KEY)

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key-here-change-in-production'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Initialize extensions
db = SQLAlchemy(app)
bcrypt = Bcrypt(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'
login_manager.login_message_category = 'info'

# User model
class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(20), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(60), nullable=False)
    age = db.Column(db.Integer, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# Load models
try:
    scaler = joblib.load("models_scaler.joblib")
    model_savings_pct = joblib.load("model_savings_pct.joblib")
    model_potential_multi = joblib.load("model_potential_multi.joblib")
    print("All models loaded successfully!")
except Exception as e:
    print(f"Error loading models: {e}")
    scaler = None
    model_savings_pct = None
    model_potential_multi = None

# Feature columns from your training
FEATURE_COLS = [
    'Income', 'Age', 'Dependents', 'Disposable_Income', 'Total_Expenses',
    'Expense_Ratio', 'Savings_Potential_Ratio', 'Rent', 'Loan_Repayment', 
    'Insurance', 'Groceries', 'Transport', 'Eating_Out', 'Entertainment', 
    'Utilities', 'Healthcare', 'Education', 'Miscellaneous', 'log_Income', 
    'log_Total_Expenses'
]

# Potential savings columns
POTENTIAL_SAVINGS_COLS = [
    'Potential_Savings_Groceries', 'Potential_Savings_Transport',
    'Potential_Savings_Eating_Out', 'Potential_Savings_Entertainment',
    'Potential_Savings_Utilities', 'Potential_Savings_Healthcare',
    'Potential_Savings_Education', 'Potential_Savings_Miscellaneous'
]

def preprocess_input(data):
    """Preprocess input data to match training format"""
    
    # Create a DataFrame with all feature columns
    input_df = pd.DataFrame(columns=FEATURE_COLS)
    
    # Fill in the provided values
    for col in FEATURE_COLS:
        if col in data:
            input_df[col] = [data[col]]
        else:
            input_df[col] = [0]  # Default value for missing columns
    
    # Calculate derived features if base features are provided
    if 'Income' in data and data['Income'] > 0:
        input_df['log_Income'] = np.log1p(data['Income'])
    
    # Calculate Total_Expenses if individual expenses are provided
    expense_cols = ['Rent', 'Loan_Repayment', 'Insurance', 'Groceries', 'Transport',
                   'Eating_Out', 'Entertainment', 'Utilities', 'Healthcare', 
                   'Education', 'Miscellaneous']
    
    total_expenses = sum(data.get(col, 0) for col in expense_cols)
    input_df['Total_Expenses'] = total_expenses
    
    if total_expenses > 0 and data.get('Income', 0) > 0:
        input_df['Expense_Ratio'] = total_expenses / data['Income']
        input_df['log_Total_Expenses'] = np.log1p(total_expenses)
    else:
        input_df['Expense_Ratio'] = 0.5  # Default reasonable value
        input_df['log_Total_Expenses'] = 0
    
    # Calculate Savings_Potential_Ratio
    if 'Disposable_Income' in data and data.get('Income', 0) > 0:
        input_df['Savings_Potential_Ratio'] = data['Disposable_Income'] / data['Income']
    else:
        input_df['Savings_Potential_Ratio'] = 0.3  # Default reasonable value
    
    return input_df

# Routes
@app.route('/')
def home():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))

@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        age = request.form.get('age')
        age_confirm = request.form.get('age_confirm')
        
        # Check if age is provided and user confirms they're 18+
        if not age or int(age) < 18:
            flash('You must be 18 years or older to register.', 'danger')
            return redirect(url_for('register'))
        
        if not age_confirm or age_confirm != 'on':
            flash('You must confirm that you are 18 years or older.', 'danger')
            return redirect(url_for('register'))
        
        # Check if passwords match
        if password != confirm_password:
            flash('Passwords do not match!', 'danger')
            return redirect(url_for('register'))
        
        # Check if user exists
        user_exists = User.query.filter((User.username == username) | (User.email == email)).first()
        if user_exists:
            flash('Username or email already exists!', 'danger')
            return redirect(url_for('register'))
        
        # Hash password and create user
        hashed_password = bcrypt.generate_password_hash(password).decode('utf-8')
        user = User(username=username, email=email, password=hashed_password, age=int(age))
        
        db.session.add(user)
        db.session.commit()
        
        flash('Account created successfully! Please log in.', 'success')
        return redirect(url_for('login'))
    
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        user = User.query.filter_by(username=username).first()
        
        if user and bcrypt.check_password_hash(user.password, password):
            login_user(user)
            next_page = request.args.get('next')
            return redirect(next_page) if next_page else redirect(url_for('dashboard'))
        else:
            flash('Login failed. Check username and password.', 'danger')
    
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

@app.route('/dashboard')
@login_required
def dashboard():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
@login_required
def predict():
    try:
        # Get data from form
        data = request.json if request.is_json else request.form.to_dict()
        
        # Convert numeric fields
        numeric_fields = [
            'Income', 'Age', 'Dependents', 'Disposable_Income', 'Rent', 
            'Loan_Repayment', 'Insurance', 'Groceries', 'Transport', 
            'Eating_Out', 'Entertainment', 'Utilities', 'Healthcare', 
            'Education', 'Miscellaneous'
        ]
        
        for field in numeric_fields:
            if field in data:
                try:
                    data[field] = float(data[field])
                except (ValueError, TypeError):
                    data[field] = 0.0
        
        # Check if models are loaded
        if any(model is None for model in [scaler, model_savings_pct, model_potential_multi]):
            return jsonify({
                'error': 'Models not loaded properly. Please check if model files exist.'
            }), 500
        
        # Preprocess input
        input_df = preprocess_input(data)
        
        # Scale the features
        input_scaled = scaler.transform(input_df)
        
        # Make predictions
        savings_pct_pred = model_savings_pct.predict(input_scaled)[0]
        potential_savings_pred = model_potential_multi.predict(input_scaled)[0]
        
        # Create response
        response = {
            'desired_savings_percentage': round(float(savings_pct_pred), 2),
            'potential_savings_by_category': {}
        }
        
        # Add potential savings by category
        for i, col in enumerate(POTENTIAL_SAVINGS_COLS):
            response['potential_savings_by_category'][col] = round(float(potential_savings_pred[i]), 2)
        
        # Calculate suggested savings amount
        income = data.get('Income', 0)
        if income > 0:
            suggested_savings = income * (savings_pct_pred / 100)
            response['suggested_savings_amount'] = round(float(suggested_savings), 2)
        else:
            response['suggested_savings_amount'] = 0.0
        
        return jsonify(response)
        
    except Exception as e:
        return jsonify({'error': f'Prediction failed: {str(e)}'}), 500


# Add this route after the existing routes in app.py
@app.route('/investment')
@login_required
def investment():
    """Investment recommendation page"""
    return render_template('investment.html')

@app.route('/predict-investment', methods=['POST'])
@login_required
def predict_investment_route():
    """API endpoint for investment prediction"""
    try:
        # Get data from request
        data = request.json if request.is_json else request.form.to_dict()
        
        # Check if models are loaded
        if investment_models is None:
            return jsonify({
                'error': 'Investment models not loaded properly. Please check if model files exist.'
            }), 500
        
        # Validate and convert input
        required_fields = ['age', 'income', 'savings', 'dependents', 'monthly_invest_amount']
        for field in required_fields:
            if field not in data:
                return jsonify({'error': f'Missing required field: {field}'}), 400
            
            try:
                data[field] = float(data[field])
            except (ValueError, TypeError):
                return jsonify({'error': f'Invalid value for {field}. Must be a number.'}), 400
        
        # Make prediction
        result = predict_investment(
            age=data['age'],
            income=data['income'],
            savings=data['savings'],
            dependents=data['dependents'],
            monthly_invest_amount=data['monthly_invest_amount']
        )
        
        if 'error' in result:
            return jsonify({'error': result['error']}), 500
            
        return jsonify(result)
        
    except Exception as e:
        return jsonify({'error': f'Investment prediction failed: {str(e)}'}), 500

@app.route('/finance-chat', methods=['POST'])
@login_required
def finance_chat():
    """Generate a short finance tip using Gemini."""
    try:
        if genai is None:
            return jsonify({'error': 'google-genai is not installed. Install it with pip install google-genai.'}), 500

        if gemini_client is None:
            return jsonify({'error': 'Set your Gemini API key in app.py before using the chat.'}), 500

        payload = request.json if request.is_json else {}
        user_message = (payload.get('message') or '').strip()

        if not user_message:
            return jsonify({'error': 'Please enter a question or finance tip request.'}), 400

        prompt = (
            "You are a helpful finance assistant for an experimental Flask app. "
            "Give concise, practical, educational finance tips only. "
            "Write in plain text with no markdown, no bold markers, and no bullet symbols like * or **. "
            "Use short numbered points or short paragraphs if helpful. "
            "Do not claim to be a licensed advisor. "
            f"User question: {user_message}"
        )

        response = gemini_client.models.generate_content(
            model=GEMINI_MODEL,
            contents=prompt
        )

        reply_text = getattr(response, 'text', None) or 'I could not generate a response.'
        return jsonify({'reply': reply_text})

    except Exception as e:
        return jsonify({'error': f'Finance chat failed: {str(e)}'}), 500

# Add investment models to health check
@app.route('/health')
def health_check():
    """Health check endpoint to verify models are loaded"""
    models_status = {
        'scaler_loaded': scaler is not None,
        'savings_pct_model_loaded': model_savings_pct is not None,
        'potential_savings_model_loaded': model_potential_multi is not None,
        'investment_models_loaded': investment_models is not None
    }
    
    return jsonify({
        'status': 'healthy' if all(models_status.values()) else 'some models missing',
        'models': models_status
    })



# Create database tables
with app.app_context():
    db.create_all()

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
